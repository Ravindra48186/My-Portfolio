
$("#berger").click(function(){
  $("#upto").slideToggle();
});